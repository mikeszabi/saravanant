//gig

function initAll()
{
	chrome.tabs.onCreated.addListener(onTabCreated);
	chrome.tabs.onRemoved.addListener(onTabRemoved);
	chrome.tabs.onSelectionChanged.addListener(onTabSelectionChanged);
	chrome.tabs.onUpdated.addListener(onTabUpdated);

	chrome.windows.onCreated.addListener(onWindowCreated);
	chrome.windows.onFocusChanged.addListener(onWindowFocusChanged);
	chrome.windows.onRemoved.addListener(onWindowRemoved);

}

function onTabCreated(tab)
{
	console.log('Tab ' + tab.id + ' ' + tab.url + ' is created');
}

function onTabRemoved(tabId)
{
	console.log('Tab ' + tabId + ' is removed');
}


function onTabSelectionChanged(tabId,selectInformation)
{
	console.log('Tab ' + tabId + ' is selected in window ' + selectInformation.windowId );
}

function onTabUpdated(tabId,changeInfornamtion,tab)
{
	console.log('Tab ' + tabId + ' is updating with url : ' + changeInfornamtion.url + ' and status is ' + changeInfornamtion.status ); 
}

function onWindowCreated(windowObj)
{
	console.log('Window ' + windowObj.id + ' is created');
}

function onWindowFocusChanged(windowId)
{
	console.log('Window ' + windowId + ' got focus');
}

function onWindowRemoved(windowId)
{
	console.log('Window ' + windowId + ' is removed');
}
