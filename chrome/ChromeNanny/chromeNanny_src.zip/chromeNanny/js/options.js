function setupDatePickers()
{
	var d = new Date();
	$("#to").val(getDateStr(d));
	d.addDays(-7);
	$("#from").val(getDateStr(d));

	$("#from").datepicker({dateFormat: 'm-d-yy'});
	$("#to").datepicker({dateFormat: 'm-d-yy'});
}

function addBlockSet()
{
	if(!validateBlockSet())
		return false;
	
	var urls = $.trim($("#URLToBeBlocked").val()).split("\n");
	urls = removeElementFromArray(null,urls);
	urls = removeElementFromArray("",urls);

	var timePeriod  = $("#timeToBeBlocked").val();
	timePeriod = convertTimePeriodStrToArray(timePeriod);

	var maxTime = $("#maxTimeADay").val()  || 0;  //assign default value as it is an optional field
	var internalName = $("#blockSetInternalName").val();
	if(internalName ==  null || internalName == "")
		internalName = "BlockSet" + new Date().getTime();

	var blockSetDtls = {
		internalName : internalName,
		name : $("#blockSetName").val(),
		urls : urls,
		interval : timePeriod,
		maxTime : maxTime ,
		activeDays : getActiveDays()
	};

	if(!validateIfUrlsAreUnique(blockSetDtls))
	{
		alert('An URL can belong to only one Block Set. Please remove the duplicate URL from this Block Set');
		return false;
	}

	var tags =  getAllLiInUl("#blockListTagsUl")
	storeBlockSet(blockSetDtls,tags);
	clearBlockListBlock();
	populateBlockSets();	
}

function validateBlockSet()
{

	//not checking if the url is a valid RFC 1738 as we "can" accept a regexp.
	// 	the problem is that i cannot find a way to "reliably" validate a regexp.
	// 	compiling a bad regexp gives syntax error and not null as output 
	// 	so not doing anything as of now for validating url --sara
	
	if($("#blockSetName").val() == "")
	{
		alert('Please enter the name of the Block Set');
		$("#blockSetName").focus();
		return false;
	}

	var urls = $.trim($("#URLToBeBlocked").val());
	if(urls == "")
	{
		alert('Please enter list of valid URLs to block');
		$("#URLToBeBlocked").focus();
		return false;
	}	
	

	var timeBlock = $("#timeToBeBlocked").val() ;

	if( timeBlock == "")
	{
		alert('Please enter a valid Time to Block ');
		$("#timeToBeBlocked").focus();
		return false;
	}	
	if(!isValidTimeBlock(timeBlock))
	{
		alert('Please a valid time block of the format hhmm-hhmm[,hhmm-hhmm]* ');
		$("#timeToBeBlocked").focus();
		return false;
	}
	
	var maxTimeADay = $("#maxTimeADay").val();
	if(maxTimeADay != "") //this is a optional field.
	{
		if(!isValidMinuteInterval(maxTimeADay))
		{
			alert('Please enter a valid minute value between 0 and 1440');
			$("#maxTimeADay").focus();
			return false;
		}
	}
	
	if($('#blockedURLsBody input:checked').length == 0)
	{
		alert('You cannot slack off all week ! Please select the days on which the URL has to be blocked !');
		return false;
	}

	return true;
}

//shud be split to validation and text later
function getArrayOfWeekDayElems()
{
	var weekDayElems= {0:"#sun", 1:"#mon", 2:"#tue", 3:"#wed", 4:"#thu", 5:"#fri", 6:"#sat"};
	return weekDayElems;
}

function getActiveDays()
{
	var weekDayElems= getArrayOfWeekDayElems(); 
	var isNoDaysSelected = true;
	var index = 0 ;
	var daysSelected = Array();
	
	$.each(weekDayElems,function(k,v){if($(v).is(":checked")) daysSelected.push(k)});
	return daysSelected.join(",");
}

function getBlockSetStr(blockSetDtls)
{
	var dtlsStr = "<table border=0 nowrap cellspacing ='0' cellpadding='0' class='ModuleSection' align='center' width='95%'>";
	var allTagsForBlockSet = getAllTagsForUrl(blockSetDtls.internalName);

	var editStr =  "&nbsp;&nbsp;<button onclick='javascript:editBlockListedUrl(\"" + blockSetDtls.internalName + "\")';>Edit</button>";
	var deleteStr =  "&nbsp;&nbsp; <button onclick='javascript:removeBlockedUrl(\"" + blockSetDtls.internalName + "\");'>Delete</button>";
	var editDeleteStr = "<span style='float:right;'>" + editStr + deleteStr + "</span>";

	dtlsStr = dtlsStr + "<tr class='tDataGridHeader'><td colspan='2'>" + blockSetDtls.name + editDeleteStr + "</td></tr>";
	dtlsStr = dtlsStr + "<tr class='tDataGridElement'><td>URLs :</td><td>" + blockSetDtls.urls.join(",") + "</td></tr>";
	dtlsStr = dtlsStr + "<tr class='tDataGridElement'><td>Blocked During :</td><td>" + convertTimePeriodArrToStr(blockSetDtls.interval)+ "</td></tr>";
	dtlsStr = dtlsStr + "<tr class='tDataGridElement'><td>Max Time :</td><td>" + blockSetDtls.maxTime+ "</td></tr>";
	dtlsStr = dtlsStr + "<tr class='tDataGridElement'><td>Apply On Days :</td><td>" + convertDayNumToDayStr(blockSetDtls.activeDays)+ "</td></tr>";
	dtlsStr = dtlsStr + "<tr class='tDataGridElement'><td>Tags:</td><td>" + allTagsForBlockSet.join(",") + "</td></tr>";
	dtlsStr += "</table>";

	return dtlsStr;
}

function handleDeleteBlockSet(blockSetName)
{
	if(!confirm('Are you sure you want to delete this Block Set ?'))
		return;
	deleteBlockSet(blockSetName);
	populateBlockSets();
}

function removeBlockedUrl(blockSetName)
{
	if(blockSetName == null) return;

	if(chrome.extension.getBackgroundPage().BackGroundManager.checkIfBlockSetShudBeBlockedNOW(blockSetName))
		challengeUser(blockSetName,'D');
	else
		handleDeleteBlockSet(blockSetName);
}

function populateBlockListFields(blockSetDtls,allTags)
{
	$("#blockSetInternalName").val(blockSetDtls.internalName);
	$("#blockSetName").val(blockSetDtls.name);
	$("#URLToBeBlocked").val(blockSetDtls.urls.join("\n"));
	$("#timeToBeBlocked").val(convertTimePeriodArrToStr(blockSetDtls.interval));
	$("#maxTimeADay").val(blockSetDtls.maxTime);

	var weekDayElems = getArrayOfWeekDayElems();
	$.each(weekDayElems, function(key,elem){$(elem).attr('checked',false);});
	$.each(blockSetDtls.activeDays.split(","), function(key,val) {$(weekDayElems[val]).attr('checked',true); } );

	addTagsToUl("#blockListTagsUl",allTags);
}

function handleEditBlockSet(blockSetName)
{
	$("#dialogBlockSet").val("");
	$("#editOrDeleteBlockSet").val("");
	var blockSetDtls = getBlockSetDtls(blockSetName);
	var allTags = getAllTagsForUrl(blockSetName);
	populateBlockListFields(blockSetDtls,allTags);
}

function editBlockListedUrl(blockSetName)
{
	if(blockSetName == null) return;
	
	if(chrome.extension.getBackgroundPage().BackGroundManager.checkIfBlockSetShudBeBlockedNOW(blockSetName))
		challengeUser(blockSetName,'E');
	else
		handleEditBlockSet(blockSetName);
}

function populateBlockSets()
{
	var allBlockedUrls = getAllBlockedUrls();
	var allBlockedUrlDtls = getAllBlockedUrlDtls();

	var allBlockSets = getAllBlockSets();
	var dtlsStr = "",blockSetDtls = {}, url = "";

	chrome.extension.getBackgroundPage().BackGroundManager.setBlockList(allBlockedUrls,allBlockedUrlDtls);

	$("#allBlockSetsTbl").find("tr:gt(0)").remove();
	$("#allBlockSetsTbl").append("<tr class='tDataGridElement'><td>&nbsp;&nbsp;<p/></td></tr>");

	$.each(allBlockSets, function(key, blockSetName){
		blockSetDtls = getBlockSetDtls(blockSetName);
		dtlsStr = getBlockSetStr(blockSetDtls);
		$("#allBlockSetsTbl").append("<tr class='tDataGridElement'><td>" + dtlsStr + "<p/></td></tr>");
	});

}

function clearBlockListBlock()
{
	$("#blockSetInternalName").val("");
	$("#blockSetName").val("");
	$('#URLToBeBlocked').val("");
	$('#timeToBeBlocked').val("");
	$('#maxTimeADay').val("");
	$('#blockListTagsUl').html("");
	//check all the checkboxes
	$('#blockedURLsBody input:checkbox').each(function(){this.checked = true;});
}

function clearBlockListUrlTags()
{
	$('#blockListTagsUl').html("");
}

function addTagToBlockListDiv()
{
	var tagName = $('#blockListAllTags').val();	
	if(tagName == null)
	{
		alert('Please retry after adding new tags in the Tags tab');
		return;
	}
	if(checkIfTagPresentInList('#blockListTagsUl',tagName))
		return;
	appendItemToUl('#blockListTagsUl', tagName);
}

function addTag()
{
	var tagName = $("#tagName").val() ;
	if(tagName == "")
	{
		alert("Please add some valid tag name !");
		return;
	}
	storeTag(tagName);
	$("#tagName").val("");
	populateTags();
}

function populateTags()
{
	var allTags = getAllTags();
	chrome.extension.getBackgroundPage().BackGroundManager.setTags(allTags);
	$("#allTagsTbl").find("tr:gt(0)").remove();
	for (var index in allTags)
	{
		var tagName = allTags[index];
		dtlsStr = tagName + "&nbsp;&nbsp;<a href='javascript:removeTag(\"" + tagName + "\")';><img src='images/delete.gif'/></a>";
		$("#allTagsTbl").append("<tr><td>" + dtlsStr + "</p></td></tr>");
	}
	updateTagsInOtherTabs(allTags);
}

function removeTag(tagName)
{
	if(!confirm('Are you sure you want to delete this tag ? '))
		return;
	deleteTag(tagName);
	populateTags();
}


function populateWhiteListedUrls()
{
	var allWhiteListedUrls = getAllWhiteListedUrls();
	var url=null,allTagsForUrl = null;
	var tagStr = "", deleteStr = "", editStr = "",dtlsStr = "";

	chrome.extension.getBackgroundPage().BackGroundManager.setWhiteList(allWhiteListedUrls);
	clearWhiteListBlock();
	$("#allWhiteListedURLsTbl").find("tr:gt(0)").remove();	
	for (var index in allWhiteListedUrls)
	{
		url = allWhiteListedUrls[index];
		allTagsForUrl = getAllTagsForUrl(url);
		if(allTagsForUrl.length > 0)
			tagStr = "&nbsp; &nbsp; Tagged : <i>" + allTagsForUrl.join(",") + "</i>";
		editStr =  "&nbsp;&nbsp;<a href='javascript:editWhiteListedUrl(\"" + url + "\")';><img src='images/edit.gif'/></a>";
		deleteStr = "&nbsp;&nbsp;<a href='javascript:removeWhiteListedUrl(\"" + url + "\")';><img src='images/delete.gif'/></a>";
		dtlsStr = url + tagStr + editStr + deleteStr; 
		$("#allWhiteListedURLsTbl").append("<tr class='tDataGridElement'><td>" + dtlsStr + "<p/></td></tr>");
	}
}

function editWhiteListedUrl(url)
{
	if(url == null)
		return;
	var allTags = getAllTagsForUrl(url);
	$("#whiteListedURL").val(url) ;
	addTagsToUl("#whiteListTagsUl",allTags);
}

function addUrlToWhiteList()
{
	var url = $("#whiteListedURL").val() ;
	var allTagsToUrl = getAllLiInUl("#whiteListTagsUl");
	storeWhiteListedUrl(url,allTagsToUrl);
	clearWhiteListBlock();
	populateWhiteListedUrls();
}


function removeWhiteListedUrl(url)
{
	if(!confirm('Are you sure you want to delete the url ? '))
		return;
	deleteWhiteListedUrl(url);
	populateWhiteListedUrls();
}

function clearWhiteListBlock()
{
	$('#whiteListedURL').val("");
	$('#whiteListTagsUl').html("");
}

function clearWhiteListUrlTags()
{
	$('#whiteListTagsUl').html("");
}

function populateGenOptions()
{
	var genOptions = getGeneralOptions();
	$("#remove").attr("checked", genOptions.modeOfBlocking == "remove");
	$("#redirect").attr("checked", genOptions.modeOfBlocking == "redirect");
	$("#redirectUrl").attr("disabled", genOptions.modeOfBlocking != "redirect");
	$("#redirectUrl").val(genOptions.redirectUrl); 
	$("#maxInActiveTimer").val(genOptions.maxInActiveTimer);
	$("#maxMinutesForBlockedUrls").val(genOptions.maxMinutesForBlockedUrls);

	if(genOptions.maxMinutesForBlockedUrls > 0)
	{
		var totalTimeSpentTodayInSecs = chrome.extension.getBackgroundPage().BackGroundManager.getTimeUsedForAllBlockedURLs();
		if(totalTimeSpentTodayInSecs >= (genOptions.maxMinutesForBlockedUrls * 60))
			$("#maxMinutesForBlockedUrls").attr('disabled',true);
	}

	$("#redirect").click(function(){$("#redirectUrl").attr('disabled',false);});
	$("#remove").click(function(){ $("#redirectUrl").val(""); $("#redirectUrl").attr('disabled',true);});
}

function saveGeneralOptions()
{
	if(!validateGeneralOptions())
		return;

	var genOptions = {
                "modeOfBlocking" : $("input[name='modeOfBlocking']:checked").val(),
                "redirectUrl" : $("#redirectUrl").val(),
                "maxInActiveTimer" : $("#maxInActiveTimer").val(),
		"maxMinutesForBlockedUrls" : $("#maxMinutesForBlockedUrls").val()
	};
	storeGeneralOptions(genOptions);
	chrome.extension.getBackgroundPage().BackGroundManager.setGenOptions(genOptions);
	alert("Options saved");
}

function validateGeneralOptions()
{
	var maxInActiveTimer = $("#maxInActiveTimer").val();
	if(!isValidMinuteInterval(maxInActiveTimer) || maxInActiveTimer < 5)
	{
		alert('Please enter a number >= 5 !');
		$('#maxInActiveTimer').focus();
		return false;
	}
	
	var maxMinutesForBlockedUrls= $("#maxMinutesForBlockedUrls").val();
	if(!isValidMinuteInterval(maxMinutesForBlockedUrls)) 
	{
		alert('Please enter a number between 0 and 1440 !');
		$('#maxMinutesForBlockedUrls').focus();
		return false;
	}

	var modeOfBlocking = $("input[name='modeOfBlocking']:checked").val();
	if(modeOfBlocking == 'redirect')
	{
		var redirectUrl = $("#redirectUrl").val();
		if(redirectUrl == "" || redirectUrl == null)
		{
			alert('Please enter a redirect url ');
			$("#redirectUrl").focus();
			return false;
		}
		
		var allWhiteListedUrls = chrome.extension.getBackgroundPage().BackGroundManager.whiteList;
		if(checkIfInArrayRegExp(redirectUrl, allWhiteListedUrls) !== false)
			return true;
		
		var allBlockListUrls = chrome.extension.getBackgroundPage().BackGroundManager.blockList;
		if(checkIfInArrayRegExp(redirectUrl, allBlockListUrls) !== false)
		{
			alert('Please enter a redirect url which is not blocked !');
			$("#redirectUrl").focus();
			return false;
		}

		if(redirectUrl.match('http') == null && redirectUrl.match('file') == null )
		{
			alert('Please enter the full url (with http or https or file as protocol )');
			$("redirectUrl").focus();
			return false;
		}
	}

	return true;
}

function updateTagsInOtherTabs(allTags)
{
	$('#whiteListAllTags').find('option').remove();
	$('#blockListAllTags').find('option').remove();

	$.each(allTags, function(val,text) {
    		$('#whiteListAllTags').append( new Option(text,text) );
    		$('#blockListAllTags').append( new Option(text,text) );
	});
}

function addTagToWhiteListDiv()
{
	var tagName = $('#whiteListAllTags').val();	
	if(tagName == null)
	{
		alert('Please retry after adding new tags in the Tags tab');
		return;
	}
	if(checkIfTagPresentInList('#whiteListTagsUl',tagName))
		return;
	appendItemToUl('#whiteListTagsUl', tagName);
}
	
function checkIfTagPresentInList(ulFieldId,tagName)
{
	var isAlreadyPresentInUL = false;
	$(ulFieldId).find('li').each(function(index) {if($(this).text() == tagName) { isAlreadyPresentInUL = true; return true;} });
	if(isAlreadyPresentInUL)
		alert('Tag already added !');
	return isAlreadyPresentInUL;
}

function setupDialog()
{
	//courtesy : http://stackoverflow.com/questions/366696/jquery-dialog-box
	challengeDialogObj = $("#challengeDiv");
	challengeDialogObj.dialog({ height: 200,
		width: 700,
		modal: true,
		position: 'center',
		autoOpen:false,
		title:'What is the airspeed velocity of an unladen swallow?',
		overlay: { opacity: 0.5, background: 'black'},
		buttons: { 
			"Allow Me !": function() {
				if(verifyChallenge())
				{
					var tempBlockSetName = $("#dialogBlockSet").val();
					var tempEditOrDelete = $("#editOrDeleteBlockSet").val();
					$("#dialogBlockSet").val("");
					$("#editOrDeleteBlockSet").val("");
					if(tempEditOrDelete == 'E')	
						handleEditBlockSet(tempBlockSetName);
					else
						handleDeleteBlockSet(tempBlockSetName);
					$("#userEnteredText").val("");
					$(this).dialog("close");
				}
				else
				{
					alert('Oops ! Wrong text . Try again !');
					$("#origText").val(getRandomStr());
					$("#userEnteredText").val("");
				}
			},
			"I Quit !" : function(){
				$("#userEnteredText").val("");
				$("#dialogBlockSet").val("");
				$("#editOrDeleteBlockSet").val("");
				$(this).dialog("close"); 
			}
		}
	});
}

function verifyChallenge()
{
	if($("#origText").val() == $("#userEnteredText").val())
		return true;
	else
		return false;
}

function challengeUser(blockSetName,editOrDelete)
{
	var randomStr = getRandomStr();
	$("#origText").val(randomStr);
	$("#dialogBlockSet").val(blockSetName);
	$("#editOrDeleteBlockSet").val(editOrDelete);
	challengeDialogObj.show();
	challengeDialogObj.dialog("open");
}

function validateRegExp()
{
	if($("#regExpUrl").val() == "")
	{
		alert('Please enter a valid Regular Expression !');
		$("#regExpUrl").focus();
		return false;
	}

	var regExpUrl = $("#regExpUrl").val();
	var testUrl = $("#urlToTest").val();

	$("#errorResultSpan").html("");
	$("#matchResultSpan").html("");

	var isRegExpValid = true;

	try
	{
		r = new RegExp(regExpUrl);
	}
	catch(e)
	{
		isRegExpValid = false;
		$("#errorResultSpan").html(e.message);
	}
	if(!isRegExpValid) return;
		
	$("#errorResultSpan").html("No error in Regular Expression");


	/* If we come here we know that reg exp is valid */
	if(testUrl == "") return ; //nothing to test

	testUrl = testUrl.toLowerCase();
	if(r.test(testUrl))
	{
		$("#matchResultSpan").html("Regular Expression matches test URL.");
	}
	else
	{
		$("#matchResultSpan").html("Regular Expression does not match test URL.");
	}

}

function resetRegExpFlds()
{
	$("#regExpUrl").val("");
	$("#urlToTest").val("");

	$("#errorResultSpan").html("");
	$("#matchResultSpan").html("");
}
